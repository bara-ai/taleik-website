# Taleik AI - AI Customer Service Assistant

## Overview

Taleik AI is a full-stack web application that provides AI-powered customer service automation for businesses. The application is built as a landing page to showcase and sell an AI assistant service that responds to customer inquiries in Arabic within 15 seconds. It's designed specifically for Saudi Arabian businesses and supports various business types from restaurants to real estate.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter for client-side routing
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: Radix UI primitives with shadcn/ui components
- **Animations**: Framer Motion for smooth animations and transitions
- **State Management**: React Query (TanStack Query) for server state
- **Build Tool**: Vite for development and building

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful API endpoints
- **Middleware**: Custom logging and error handling
- **Development**: Hot reload with Vite integration

### Database Architecture
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Database**: PostgreSQL (configured but not fully implemented)
- **Storage**: Currently using in-memory storage with MemStorage class
- **Migrations**: Drizzle Kit for schema migrations

## Key Components

### Landing Page Sections
1. **Hero Section**: Main value proposition with gradient background
2. **Problem Section**: Identifies customer pain points
3. **Features Section**: Showcases AI assistant capabilities
4. **Business Selector**: Interactive component for different business types
5. **Integration Section**: Shows platform integrations (WhatsApp, Instagram, etc.)
6. **Pricing Section**: Single package pricing with features list
7. **How It Works**: 3-step process explanation
8. **Testimonials**: Customer success stories
9. **FAQ Section**: Common questions with Arabic answers
10. **Final CTA**: Call-to-action with urgency

### UI Component System
- Comprehensive component library based on Radix UI
- Consistent design tokens and theming
- Custom animations and interactions
- Arabic language support with RTL considerations

### Form Handling
- Contact form with validation using Zod schemas
- Demo request functionality
- Newsletter subscription
- Form validation with Arabic error messages

## Data Flow

1. **User Interaction**: Users interact with the landing page components
2. **Form Submission**: Contact forms send data to backend API endpoints
3. **Validation**: Server validates data using Zod schemas
4. **Response**: Server responds with success/error messages in Arabic
5. **UI Updates**: Frontend updates UI based on API responses using React Query

## External Dependencies

### Frontend Dependencies
- **React**: Core UI library
- **Wouter**: Lightweight routing
- **Framer Motion**: Animations and transitions
- **React Query**: Server state management
- **React Hook Form**: Form handling
- **Zod**: Schema validation
- **Tailwind CSS**: Utility-first styling
- **Radix UI**: Accessible component primitives
- **Lucide React**: Icon library

### Backend Dependencies
- **Express**: Web framework
- **Drizzle ORM**: Database ORM
- **Zod**: Data validation
- **Neon Database**: PostgreSQL provider
- **Connect PG Simple**: Session store (configured but not used)

### Development Dependencies
- **Vite**: Build tool and dev server
- **TypeScript**: Type checking
- **ESBuild**: Production bundling
- **PostCSS**: CSS processing
- **Autoprefixer**: CSS vendor prefixes

## Deployment Strategy

### Build Process
1. **Frontend**: Vite builds React application to `dist/public`
2. **Backend**: ESBuild bundles server code to `dist/index.js`
3. **Assets**: Static files served from build directory

### Environment Configuration
- Database URL configuration via environment variables
- Development and production environment handling
- Replit-specific optimizations and integrations

### Production Setup
- Express serves static files in production
- API routes handle backend functionality
- Database migrations managed through Drizzle Kit
- Error handling and logging for production monitoring

### Development Features
- Hot module replacement via Vite
- Automatic server restart with tsx
- Development-only error overlays
- Replit integration for cloud development

The application is designed as a high-converting landing page with modern web technologies, focusing on Arabic language support and Saudi Arabian market needs. The architecture supports future expansion to full AI assistant functionality while currently serving as an effective marketing and lead generation tool.