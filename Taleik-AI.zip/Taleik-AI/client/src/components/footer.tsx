import { motion } from "framer-motion";
import { Bot } from "lucide-react";
import { FaTwitter, FaLinkedin, FaInstagram } from "react-icons/fa";

export default function Footer() {
  const services = [
    "خدمة العملاء الآلية",
    "تكامل المنصات",
    "تحليلات الأداء",
    "دعم فني 24/7"
  ];

  const company = [
    "من نحن",
    "فريق العمل",
    "المدونة",
    "الوظائف"
  ];

  const support = [
    "مركز المساعدة",
    "اتصل بنا",
    "سياسة الخصوصية",
    "شروط الاستخدام"
  ];

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <motion.div 
              whileHover={{ scale: 1.05 }}
              className="text-2xl font-bold mb-4 flex items-center"
            >
              <Bot className="ml-2 text-primary" size={28} />
              Taleik AI
            </motion.div>
            <p className="text-gray-400 mb-4">
              موظّف ذكاء اصطناعي يرد على عملاءك في 15 ثانية
            </p>
            <div className="flex space-x-4 space-x-reverse">
              <motion.a 
                href="#" 
                whileHover={{ scale: 1.2 }}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <FaTwitter size={20} />
              </motion.a>
              <motion.a 
                href="#" 
                whileHover={{ scale: 1.2 }}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <FaLinkedin size={20} />
              </motion.a>
              <motion.a 
                href="#" 
                whileHover={{ scale: 1.2 }}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <FaInstagram size={20} />
              </motion.a>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">الخدمات</h3>
            <ul className="space-y-2 text-gray-400">
              {services.map((service, index) => (
                <li key={index}>
                  <a href="#" className="hover:text-white transition-colors">
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">الشركة</h3>
            <ul className="space-y-2 text-gray-400">
              {company.map((item, index) => (
                <li key={index}>
                  <a href="#" className="hover:text-white transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">الدعم</h3>
            <ul className="space-y-2 text-gray-400">
              {support.map((item, index) => (
                <li key={index}>
                  <a href="#" className="hover:text-white transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 Taleik AI. جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  );
}
