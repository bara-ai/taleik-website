import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Star } from "lucide-react";
import ScrollReveal from "./scroll-reveal";
import { useLanguage } from "@/hooks/use-language";

export default function FinalCTA() {
  const { t } = useLanguage();

  const handleJoinWaitlist = () => {
    window.dispatchEvent(new CustomEvent('openWaitingListFromCTA'));
  };

  return (
    <section className="py-20 gradient-bg text-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <ScrollReveal>
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <div className="text-6xl mb-4">🚀</div>
          </motion.div>

          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            {t('finalCta.title', 'ابدأ رحلتك مع طليق اليوم')}
          </h2>

          <p className="text-xl mb-8 text-white/90">
            {t('finalCta.subtitle', 'انضم إلى مئات الشركات التي وثقت في طليق لتحسين خدمة العملاء')}
          </p>

          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button 
              size="lg" 
              className="bg-white text-primary hover:bg-gray-100 text-lg px-8 py-4"
              onClick={handleJoinWaitlist}
            >
              {t('finalCta.button', 'انضم لقائمة الانتظار')}
              <ArrowLeft className="mr-2" size={20} />
            </Button>
          </motion.div>

          <div className="flex items-center justify-center mt-6 text-white/80">
            <div className="flex text-yellow-400 ml-2">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={16} fill="currentColor" />
              ))}
            </div>
            <span className="text-sm">
              {t('finalCta.rating', 'تقييم 4.9/5 من أكثر من 500 عميل')}
            </span>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}