import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Star, User } from "lucide-react";
import ScrollReveal from "./scroll-reveal";

export default function Testimonials() {
  const testimonials = [
    {
      name: "أحمد البرغوثي",
      business: "مكتب خدمات سياحية",
      text: "كنت أضيع 3 ساعات يومياً على الردود المتكررة. الآن طليق يرد على 80% من الاستفسارات والباقي يوصلني منظم ومفهوم.",
      color: "bg-primary",
    },
    {
      name: "نورا دوابشة",
      business: "متجر إكسسوارات نسائية",
      text: "زبائن محل الإكسسوارات يسألون نفس الأسئلة: الأسعار، التوصيل، المقاسات. طليق وفر علي وقت كثير وزاد مبيعاتي 20%.",
      color: "bg-secondary",
    },
    {
      name: "خالد نواهضة",
      business: "معرض جوالات",
      text: "العملاء يحبون الرد السريع حتى لو كان منتصف الليل. مافي حدا بشكي من التأخير والمبيعات زادت بشكل ملحوظ.",
      color: "bg-green-600",
    },
    {
      name: "فاطمة الطريفي",
      business: "مطعم وجبات صحية",
      text: "صراحة استغربت من دقة الردود. يفهم حتى لو العميل كتب بالعامية الفلسطينية ويرد بنفس الأسلوب. مريح جداً.",
      color: "bg-blue-500",
    },
    {
      name: "سارة النبالي",
      business: "متجر عبايات أونلاين",
      text: "أهم شي عندي إن العميل يحس بالاهتمام. طليق يسأل الأسئلة الصحيحة ويوجه العميل للمنتج المناسب.",
      color: "bg-pink-500",
    },
    {
      name: "عبدالله لدادوة",
      business: "شركة صيانة تكييف",
      text: "قبل كان العملاء يتركون المحادثة لما نتأخر في الرد. الآن المحادثات تكمل لنهاية الطلب. فرق واضح.",
      color: "bg-green-500",
    },
  ];

  return (
    <section id="testimonials" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              شهادات العملاء
            </h2>
            <p className="text-xl text-gray-600">
              ماذا يقول عملاؤنا عن تجربتهم
            </p>
          </div>
        </ScrollReveal>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <ScrollReveal key={index} delay={index * 0.1}>
              <motion.div whileHover={{ y: -8 }} transition={{ duration: 0.3 }}>
                <Card className="h-full card-hover">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <div
                        className={`w-12 h-12 ${testimonial.color} rounded-full flex items-center justify-center ml-3`}
                      >
                        <User className="text-white" size={24} />
                      </div>
                      <div>
                        <h4 className="font-semibold">{testimonial.name}</h4>
                        <p className="text-sm text-gray-500">
                          {testimonial.business}
                        </p>
                      </div>
                    </div>
                    <div className="text-yellow-500 mb-3 flex">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} size={16} fill="currentColor" />
                      ))}
                    </div>
                    <p className="text-gray-600 text-sm italic">
                      "{testimonial.text}"
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
