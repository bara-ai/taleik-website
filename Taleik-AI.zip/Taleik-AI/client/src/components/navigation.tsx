import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Menu, X, Bot } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";
import { useABTest } from "@/hooks/use-ab-test";
import LanguageToggle from "@/components/language-toggle";

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const { t } = useLanguage();
  const { trackConversion } = useABTest();

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
    setIsOpen(false);
  };

  const handleTryNow = () => {
    trackConversion("heroHeadline", "nav_try_now_click");
    // Open chat instead of waiting list modal
    window.dispatchEvent(new CustomEvent('openChat'));
  };

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed top-0 w-full bg-white/90 backdrop-blur-md z-50 border-b border-gray-100"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <motion.div 
              whileHover={{ scale: 1.05 }}
              className="text-2xl font-bold text-gradient flex items-center"
            >
              <Bot className="ml-2 text-primary" size={28} />
              Taleik AI
            </motion.div>
          </div>
          
          <div className="hidden md:flex items-center space-x-4 space-x-reverse">
            <button 
              onClick={() => scrollToSection('features')}
              className="text-gray-700 hover:text-primary transition-colors"
            >
              {t('nav.features')}
            </button>
            <button 
              onClick={() => scrollToSection('pricing')}
              className="text-gray-700 hover:text-primary transition-colors"
            >
              {t('nav.pricing')}
            </button>
            <button 
              onClick={() => scrollToSection('testimonials')}
              className="text-gray-700 hover:text-primary transition-colors"
            >
              {t('nav.testimonials')}
            </button>
            <button 
              onClick={() => scrollToSection('contact')}
              className="text-gray-700 hover:text-primary transition-colors"
            >
              {t('nav.contact')}
            </button>
            <LanguageToggle />
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button onClick={handleTryNow} className="bg-primary text-white hover:bg-secondary">
                {t('nav.tryNow')}
              </Button>
            </motion.div>
          </div>
          
          <div className="md:hidden">
            <button 
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-700 hover:text-primary"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
        
        {/* Mobile menu */}
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t border-gray-100"
          >
            <div className="py-4 space-y-4">
              <button 
                onClick={() => scrollToSection('features')}
                className="block w-full text-right px-4 py-2 text-gray-700 hover:text-primary"
              >
                {t('nav.features')}
              </button>
              <button 
                onClick={() => scrollToSection('pricing')}
                className="block w-full text-right px-4 py-2 text-gray-700 hover:text-primary"
              >
                {t('nav.pricing')}
              </button>
              <button 
                onClick={() => scrollToSection('testimonials')}
                className="block w-full text-right px-4 py-2 text-gray-700 hover:text-primary"
              >
                {t('nav.testimonials')}
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className="block w-full text-right px-4 py-2 text-gray-700 hover:text-primary"
              >
                {t('nav.contact')}
              </button>
              <div className="px-4 space-y-2">
                <LanguageToggle />
                <Button onClick={handleTryNow} className="w-full bg-primary text-white hover:bg-secondary">
                  {t('nav.tryNow')}
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </motion.nav>
  );
}
