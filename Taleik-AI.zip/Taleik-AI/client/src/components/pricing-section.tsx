import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Bot,
  Users,
  MessageCircle,
  UserPlus,
  Ticket,
  Link2,
  Zap,
  Clock,
  Smartphone,
  BarChart,
  Shield,
  Headphones,
  Check,
} from "lucide-react";
import ScrollReveal from "./scroll-reveal";

export default function PricingSection() {
  const features = [
    {
      icon: Bot,
      title: "2000 رد ذكي شهرياً",
      description: "ردود تلقائية ذكية على جميع استفسارات العملاء",
    },
    {
      icon: Users,
      title: "ردود بشرية غير محدودة",
      description: "ردود من فريق الدعم البشري بدون حدود أو قيود",
    },
    {
      icon: MessageCircle,
      title: "محادثات غير محدودة",
      description: "لا حدود على عدد المحادثات مع العملاء",
    },
    {
      icon: UserPlus,
      title: "عضو فريق واحد",
      description: "إمكانية إضافة عضو واحد لفريقك لإدارة النظام",
    },
    {
      icon: Ticket,
      title: "500 تذكرة شهرياً",
      description: "معالجة حتى 500 تذكرة دعم فني شهرياً",
    },
    {
      icon: Link2,
      title: "تكامل مع سلة وشوبيفاي",
      description: "ربط مباشر مع متاجر سلة وShopify لإدارة المنتجات والطلبات",
    },
    {
      icon: Zap,
      title: "رد خلال 15 ثانية",
      description: "استجابة فورية لجميع الرسائل على مدار الساعة",
    },
    {
      icon: Clock,
      title: "عمل 24/7",
      description: "لا إجازات، لا نوم، خدمة مستمرة",
    },
    {
      icon: Smartphone,
      title: "دعم 5 منصات",
      description: "واتساب، تيليجرام، إنستجرام، فيسبوك، موقعك",
    },
    {
      icon: BarChart,
      title: "تقارير مفصلة",
      description: "احصائيات شاملة عن أداء المحادثات",
    },
    {
      icon: Shield,
      title: "أمان متقدم",
      description: "حماية كاملة لبيانات عملائك",
    },
    {
      icon: Headphones,
      title: "دعم فني مباشر",
      description: "فريق دعم متخصص باللغة العربية",
    },
  ];

  return (
    <section id="pricing" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4"></h2>
            <p className="text-xl text-gray-600"></p>
          </div>
        </ScrollReveal>

        {/* Features List */}
        <ScrollReveal>
          <Card className="shadow-lg">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-center mb-8 flex items-center justify-center">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="ml-2"
                >
                  ✨
                </motion.div>
                كل ما تحتاجه في باقة واحدة
              </h3>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {features.map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="flex items-start"
                  >
                    <feature.icon
                      className="text-primary text-xl ml-3 mt-1 flex-shrink-0"
                      size={20}
                    />
                    <div>
                      <h4 className="font-semibold mb-1">{feature.title}</h4>
                      <p className="text-sm text-gray-600">
                        {feature.description}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>

              <Card className="mt-8 bg-gradient-to-r from-primary/10 to-secondary/10">
                <CardContent className="p-6 text-center">
                  <h4 className="text-xl font-bold text-gray-900 mb-2">
                    وفّر 60-80% من تكلفة موظف خدمة العملاء
                  </h4>
                  <p className="text-lg text-gray-600"></p>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </ScrollReveal>
      </div>
    </section>
  );
}
