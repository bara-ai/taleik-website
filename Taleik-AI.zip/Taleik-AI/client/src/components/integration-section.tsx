import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, Instagram, Globe, Send, Facebook, Store, ShoppingBag } from "lucide-react";
import ScrollReveal from "./scroll-reveal";

export default function IntegrationSection() {
  const socialPlatforms = [
    {
      icon: MessageCircle,
      name: "WhatsApp",
      description: "رسائل واتساب المباشرة",
      color: "from-green-50 to-emerald-50",
      iconBg: "bg-green-500",
      features: [
        "الرد على الاستفسارات فوراً",
        "إرسال كتالوجات المنتجات",
        "جدولة المواعيد",
        "تتبع الطلبات"
      ]
    },
    {
      icon: Instagram,
      name: "Instagram",
      description: "رسائل انستغرام المباشرة",
      color: "from-pink-50 to-rose-50",
      iconBg: "bg-pink-500",
      features: [
        "إدارة الرسائل المباشرة",
        "تحويل المتابعين إلى عملاء",
        "إرسال محتوى مخصص",
        "تتبع التفاعل والمشاركات"
      ]
    },
    {
      icon: Globe,
      name: "الموقع الإلكتروني",
      description: "شات بوت موقعك",
      color: "from-blue-50 to-indigo-50",
      iconBg: "bg-blue-500",
      features: [
        "الرد على الزوار فوراً",
        "توجيه العملاء للصفحات المناسبة",
        "جمع بيانات العملاء المحتملين",
        "تقديم الدعم الفني"
      ]
    },
    {
      icon: Send,
      name: "Telegram",
      description: "قنوات ومجموعات تليجرام",
      color: "from-cyan-50 to-teal-50",
      iconBg: "bg-cyan-500",
      features: [
        "إدارة المجموعات تلقائياً",
        "نشر المحتوى المجدول",
        "الرد على الأسئلة الشائعة",
        "إرسال الإشعارات المهمة"
      ]
    }
  ];

  const ecommercePlatforms = [
    {
      icon: ShoppingBag,
      name: "سلة",
      url: "https://salla.sa",
      color: "bg-purple-600",
      features: [
        "البحث واقتراح المنتجات المناسبة للعملاء",
        "تتبع الطلبات وتقديم التحديثات",
        "معالجة طلبات الإرجاع والاستبدال",
        "دعم عمليات الدفع والشراء"
      ]
    },
    {
      icon: Store,
      name: "Shopify",
      url: "https://shopify.com",
      color: "bg-green-600",
      features: [
        "عرض وتوصية المنتجات الأكثر مبيعاً",
        "تحديث معلومات الشحن والخصومات",
        "إدارة استفسارات المرتجعات",
        "تقديم الدعم الفني للمتجر"
      ]
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              يتكامل مع جميع منصاتك
            </h2>
            <p className="text-xl text-gray-600 mb-2">
              بضغطة زر واحدة
            </p>
            <p className="text-lg text-gray-500">
              سواء كنت صاحب عمل تقليدي أو متجر إلكتروني، نحن نخدم الجميع
            </p>
          </div>
        </ScrollReveal>
        
        <div className="mb-16">
          <ScrollReveal>
            <h3 className="text-2xl font-bold text-center mb-8">منصات التواصل الاجتماعي</h3>
          </ScrollReveal>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {socialPlatforms.map((platform, index) => (
              <ScrollReveal key={index} delay={index * 0.1}>
                <motion.div
                  whileHover={{ y: -8 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className={`h-full bg-gradient-to-br ${platform.color} card-hover`}>
                    <CardContent className="p-6">
                      <div className={`w-12 h-12 ${platform.iconBg} rounded-xl flex items-center justify-center mb-4`}>
                        <platform.icon className="text-white" size={24} />
                      </div>
                      <h4 className="text-lg font-semibold mb-2">{platform.name}</h4>
                      <p className="text-sm text-gray-600 mb-4">{platform.description}</p>
                      <ul className="text-xs text-gray-600 space-y-1">
                        {platform.features.map((feature, idx) => (
                          <li key={idx}>• {feature}</li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </motion.div>
              </ScrollReveal>
            ))}
          </div>
        </div>
        
        <ScrollReveal>
          <Card className="bg-gradient-to-r from-primary/5 to-secondary/5">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">المتاجر الإلكترونية</h3>
                <p className="text-lg text-gray-600">دعم عملاء شامل لجميع المتاجر الإلكترونية</p>
              </div>
              
              <div className="grid md:grid-cols-2 gap-8">
                {ecommercePlatforms.map((platform, index) => (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.02 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card className="bg-white shadow-lg">
                      <CardContent className="p-6">
                        <div className="flex items-center mb-4">
                          <div className={`w-12 h-12 ${platform.color} rounded-lg flex items-center justify-center ml-3`}>
                            <platform.icon className="text-white" size={24} />
                          </div>
                          <div>
                            <h4 className="font-semibold">{platform.name}</h4>
                            <p className="text-sm text-gray-500">{platform.url}</p>
                          </div>
                        </div>
                        <ul className="text-sm text-gray-600 space-y-2">
                          {platform.features.map((feature, idx) => (
                            <li key={idx}>• {feature}</li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </ScrollReveal>
        
        <ScrollReveal delay={0.3}>
          <div className="text-center mt-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              لا تترك عملاءك ينتظرون
            </h3>
            <p className="text-lg text-gray-600">
              اربط جميع منصاتك في دقائق واحصل على موظف ذكي يعمل بلا توقف
            </p>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
