import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  UtensilsCrossed,
  ShoppingCart,
  Stethoscope,
  Scissors,
  Pill,
  Dumbbell,
  Bed,
  Home,
  GraduationCap,
  Car,
  Gavel,
  Fan,
  Check,
} from "lucide-react";
import ScrollReveal from "./scroll-reveal";
import AnimatedCounter from "./animated-counter";

export default function BusinessSelector() {
  const [selectedBusiness, setSelectedBusiness] = useState<string | null>(null);

  const businessTypes = [
    { icon: UtensilsCrossed, name: "المطاعم", color: "text-primary" },
    {
      icon: ShoppingCart,
      name: "التجارة الإلكترونية",
      color: "text-secondary",
    },
    { icon: Stethoscope, name: "المراكز الطبية", color: "text-green-600" },
    { icon: Scissors, name: "صالونات التجميل", color: "text-pink-600" },
    { icon: Pill, name: "الصيدليات", color: "text-blue-600" },
    { icon: Dumbbell, name: "مراكز اللياقة", color: "text-orange-600" },
    { icon: Bed, name: "الفنادق", color: "text-indigo-600" },
    { icon: Home, name: "العقارات", color: "text-green-600" },
    { icon: GraduationCap, name: "المدارس", color: "text-purple-600" },
    { icon: Car, name: "صيانة السيارات", color: "text-red-600" },
    { icon: Gavel, name: "المحاماة", color: "text-gray-700" },
    { icon: Fan, name: "خدمات التنظيف", color: "text-teal-600" },
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              جرّب طليق الآن
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              تحدث مع الذكاء الاصطناعي مباشرة
            </p>
            <Card className="max-w-2xl mx-auto">
              <CardContent className="p-6">
                <p className="text-lg text-gray-700 mb-6">
                  اكتشف كيف سيساعد عملاءك ويزيد مبيعاتك
                </p>
                <h3 className="text-xl font-semibold mb-4">
                  اختر نوع عملك لترى كيف يساعدك طليق
                </h3>
                <p className="text-sm text-gray-500 mb-6">
                  انقر على أي نوع عمل لترى الفوائد المحددة
                </p>
              </CardContent>
            </Card>
          </div>
        </ScrollReveal>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-12">
          {businessTypes.map((business, index) => (
            <ScrollReveal key={index} delay={index * 0.05}>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedBusiness(business.name)}
              >
                <Card
                  className={`cursor-pointer transition-all duration-300 card-hover ${
                    selectedBusiness === business.name
                      ? "ring-2 ring-primary bg-primary/5"
                      : ""
                  }`}
                >
                  <CardContent className="p-4 text-center">
                    <business.icon
                      className={`${business.color} mx-auto mb-2`}
                      size={32}
                    />
                    <div className="font-semibold text-sm">{business.name}</div>
                  </CardContent>
                </Card>
              </motion.div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
