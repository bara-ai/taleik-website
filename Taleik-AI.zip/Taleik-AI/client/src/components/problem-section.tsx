import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Bell, DollarSign, Trophy } from "lucide-react";
import ScrollReveal from "./scroll-reveal";

export default function ProblemSection() {
  const problems = [
    {
      icon: Bell,
      title: "إشعارات واتساب وإنستغرام لا تتوقف",
      description: "رسائل العملاء تتراكم والفريق لا يلحق بالردود السريعة",
      color: "text-red-600",
      bgColor: "bg-red-100"
    },
    {
      icon: DollarSign,
      title: "تكلفة التوظيف والتدريب عالية",
      description: "الردود اليدوية بطيئة ومتأخرة وتكلف الكثير",
      color: "text-yellow-600",
      bgColor: "bg-yellow-100"
    },
    {
      icon: Trophy,
      title: "منافسك يرد أسرع ويكسب الصفقة",
      description: "قبل أن تكتب «هلا» أو «أهلاً وسهلاً» الفرصة الذهبية تضيع...",
      color: "text-blue-600",
      bgColor: "bg-blue-100"
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              رسائل العملاء تتكدّس؟
            </h2>
            <p className="text-xl text-red-600 font-semibold">
              كل دقيقة تأخير = عميل ضائع
            </p>
          </div>
        </ScrollReveal>
        
        <div className="grid md:grid-cols-3 gap-8">
          {problems.map((problem, index) => (
            <ScrollReveal key={index} delay={index * 0.1}>
              <motion.div
                whileHover={{ y: -8 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="h-full card-hover">
                  <CardContent className="p-6">
                    <div className={`w-12 h-12 ${problem.bgColor} rounded-lg flex items-center justify-center mb-4`}>
                      <problem.icon className={`${problem.color} text-xl`} size={24} />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">{problem.title}</h3>
                    <p className="text-gray-600">{problem.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            </ScrollReveal>
          ))}
        </div>
        
        <ScrollReveal delay={0.4}>
          <div className="text-center mt-12">
            <p className="text-2xl font-bold text-gray-900 mb-4">
              الفرصة الذهبية تضيع كل 15 ثانية…
            </p>
            <p className="text-xl text-primary">
              إلا إذا كان لديك موظف يرد فوراً
            </p>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
