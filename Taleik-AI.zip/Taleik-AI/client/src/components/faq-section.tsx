import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronDown, MessageCircle, Mail } from "lucide-react";
import ScrollReveal from "./scroll-reveal";

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: "ما الفرق بين الردود الذكية والردود البشرية في 'طليق؟",
      answer:
        "الردود الذكية هي الردود التلقائية من الذكاء الاصطناعي على الاستفسارات الشائعة. أما الردود البشرية فهي عندما يتدخل فريقك أو فريق الدعم لدينا للرد على استفسارات معقدة تحتاج تدخل بشري.",
    },
    {
      question: "كيف يعمل 'طليق مع عملي؟",
      answer:
        "نقوم بربط 'طليق مع منصات التواصل الخاصة بك (واتساب، إنستغرام، موقعك). بعدها يقوم بالرد على العملاء تلقائياً، وتصفية الاستفسارات، وتحويل المهم منها لك كتذاكر منظمة.",
    },
    {
      question: "هل يحتاج 'طليق إلى تدريب طويل أو خبرة تقنية؟",
      answer:
        "لا أبداً! 'طليق مُعد مسبقاً ويبدأ العمل فوراً. فقط تحتاج 10 دقائق لربط حساباتك وإضافة معلومات عملك الأساسية. لا حاجة لأي خبرة تقنية.",
    },
    {
      question: "هل يدعم 'طليق اللغات والثقافات المختلفة؟",
      answer:
        "نعم! 'طليق مدرب على فهم اللغات المختلفة والثقافات المتنوعة، ويرد بنفس أسلوب العميل ليشعر بالراحة والألفة.",
    },
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-16 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              الأسئلة الشائعة
            </h2>
            <p className="text-xl text-gray-600">
              كل ما تريد معرفته عن 'طليق' وباقة المشاريع الصغيرة
            </p>
          </div>
        </ScrollReveal>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <ScrollReveal key={index} delay={index * 0.1}>
              <Card className="overflow-hidden">
                <motion.button
                  onClick={() => toggleFAQ(index)}
                  className="w-full p-6 text-right flex justify-between items-center hover:bg-gray-50 transition-colors"
                  whileHover={{ x: -5 }}
                >
                  <motion.div
                    animate={{ rotate: openIndex === index ? 180 : 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <ChevronDown size={24} />
                  </motion.div>
                  <span className="font-semibold text-lg">{faq.question}</span>
                </motion.button>
                <AnimatePresence>
                  {openIndex === index && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <CardContent className="p-6 pt-0 text-gray-600">
                        {faq.answer}
                      </CardContent>
                    </motion.div>
                  )}
                </AnimatePresence>
              </Card>
            </ScrollReveal>
          ))}
        </div>

        <ScrollReveal delay={0.5}>
          <div className="text-center mt-12">
            <h3 className="text-xl font-semibold mb-4">
              لديك سؤال آخر؟ تواصل معنا مباشرة!
            </h3>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4 sm:space-x-reverse">
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button 
                  className="bg-green-500 text-white hover:bg-green-600"
                  onClick={() => window.open('https://wa.me/972597740967', '_blank')}
                >
                  <MessageCircle className="ml-2" size={20} />
                  واتساب: +972597740967
                </Button>
              </motion.div>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  variant="outline"
                  className="border-blue-500 text-blue-500 hover:bg-blue-50"
                  onClick={() => window.open('mailto:baraa@taleik.ai', '_blank')}
                >
                  <Mail className="ml-2" size={20} />
                  baraa@taleik.ai
                </Button>
              </motion.div>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
