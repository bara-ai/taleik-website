import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Star } from "lucide-react";
import ScrollReveal from "./scroll-reveal";
import { useLanguage } from "@/hooks/use-language";
import { useABTest } from "@/hooks/use-ab-test";

export default function HeroSection() {
  const { t } = useLanguage();
  const { getVariant } = useABTest();
  
  const headlineVariant = getVariant("heroHeadline");

  return (
    <section className="pt-24 pb-16 gradient-bg text-white min-h-screen flex items-center">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="text-center">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="mb-8"
            >
              <Badge variant="secondary" className="bg-white/20 text-white border-none">
                <Star className="ml-2" size={16} />
                Taleik AI
                <Star className="mr-2" size={16} />
              </Badge>
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="md:text-6xl font-bold mb-6 text-[39px] pt-[33px] pb-[33px]"
            >
              {headlineVariant === "control" ? (
                <>
                  {t('hero.title')}
                </>
              ) : (
                <>
                  موظّف ذكاء اصطناعي يرد على عملائك <br />
                  في اقل من 15 ثانية!
                </>
              )}
            </motion.h1>
            
            </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
