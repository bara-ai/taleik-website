import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Send, Bot, User, MessageCircle, X } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

interface Message {
  id: string;
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
}

export default function ChatDemo() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { language, t } = useLanguage();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const handleOpenChat = () => {
      setIsOpen(true);
      initializeChat();
    };

    const handleOpenWaitingList = () => {
      setIsOpen(false);
      // Dispatch event to open waiting list modal
      window.dispatchEvent(new CustomEvent('openWaitingListFromChat'));
    };

    window.addEventListener('openChat', handleOpenChat);
    window.addEventListener('openWaitingList', handleOpenWaitingList);

    return () => {
      window.removeEventListener('openChat', handleOpenChat);
      window.removeEventListener('openWaitingList', handleOpenWaitingList);
    };
  }, []);

  const predefinedResponses = {
    ar: {
      greeting: "أهلاً وسهلاً! أنا مساعد طليق الذكي 🤖 \n\nيمكنني مساعدتك في:\n• معرفة الأسعار والباقات\n• شرح المميزات والخدمات\n• التكامل مع منصاتك\n• طلب عرض توضيحي\n\nكيف أستطيع مساعدتك اليوم؟",
      pricing: "💰 باقة طليق تبدأ من $59 شهرياً وتشمل:\n\n✅ ردود فورية خلال 15 ثانية\n✅ تكامل مع 5+ منصات\n✅ فرز العملاء المهتمين تلقائياً\n✅ تقارير مفصلة لحظية\n✅ دعم فني 24/7\n\nهذا يوفر عليك 80% من تكلفة موظف خدمة العملاء! 📈\n\nتريد تجربة مجانية أم لديك أسئلة أخرى؟",
      features: "🚀 مميزات طليق المذهلة:\n\n⚡ رد فوري خلال 15 ثانية\n🎯 فرز العملاء الجادين من المتصفحين\n📋 تذاكر منظمة لفريقك\n🔗 تكامل سلس مع جميع المنصات\n📊 تحليلات وإحصائيات دقيقة\n🌐 دعم باللغة العربية\n⏰ عمل متواصل 24/7 بدون إجازات\n\nأي ميزة تهمك أكثر؟ أو تريد رؤية عرض توضيحي؟",
      integration: "🔗 طليق يتكامل مع جميع منصاتك:\n\n📱 واتساب وواتساب بيزنس\n📸 إنستغرام ورسائله المباشرة\n✈️ تليجرام\n🌐 موقعك الإلكتروني\n🛒 متجر سلة\n🛍️ شوبيفاي\n📘 فيسبوك ماسنجر\n\nالربط يتم في أقل من 5 دقائق ولا يحتاج خبرة تقنية!\n\nأي منصة تستخدم حالياً وتريد ربطها أولاً؟",
      support: "🎧 فريق الدعم الفني في طليق:\n\n✅ متخصصون بلغات متعددة\n✅ متاحون 24/7 طوال أيام السنة\n✅ رد سريع خلال دقائق\n✅ حل المشاكل عن بُعد\n\n📞 طرق التواصل:\n• البريد الإلكتروني: support@taleik.ai\n• الدردشة المباشرة على الموقع\n\nهل تحتاج مساعدة تقنية معينة؟",
      demo: "🎯 تجربة طليق المجانية:\n\n1️⃣ اختر نوع عملك\n2️⃣ أدخل بياناتك\n3️⃣ احصل على رابط التجربة فوراً\n\n📧 سنرسل لك:\n• رابط لوحة التحكم\n• دليل الاستخدام\n• جلسة تدريب مجانية\n\nكل هذا خلال 5 دقائق! هل تريد البدء الآن؟",
      businessTypes: {
        "المطاعم": "🍽️ طليق مثالي للمطاعم:\n\n• رد على استفسارات المنيو والأسعار\n• حجز الطاولات تلقائياً\n• استقبال طلبات التوصيل\n• تحديد المواعيد المتاحة\n\nيزيد طلباتك بنسبة 40% ويوفر وقت الموظفين!",
        "العقارات": "🏠 طليق يساعد مكاتب العقارات:\n\n• جمع معلومات العملاء المهتمين\n• تحديد الميزانية والمواصفات\n• ترتيب مواعيد المعاينة\n• إرسال العروض المناسبة\n\nيضاعف عدد العملاء المؤهلين بـ 3 مرات!",
        "الصيدليات": "💊 طليق للصيدليات:\n\n• الرد على استفسارات الأدوية\n• التأكد من توفر المنتجات\n• حجز الأدوية للاستلام\n• تذكير بمواعيد الدواء\n\nيحسن خدمة العملاء ويزيد المبيعات بشكل ملحوظ!"
      },
      contact: "📞 تريد التحدث مع فريق المبيعات؟\n\nيمكنك:\n• ملء نموذج الانتظار أعلاه\n• البريد الإلكتروني: sales@taleik.ai\n• الدردشة المباشرة على الموقع\n\nأو اتركلي بياناتك هنا وسأمررها للفريق مباشرة! 📝",
      default: "🤔 أفهم استفسارك، لكن للحصول على إجابة دقيقة ومفصلة عن هذا الموضوع، سأحيل سؤالك لخبرائنا.\n\n👥 فريق المبيعات سيتواصل معك خلال ساعة واحدة لمناقشة احتياجاتك بالتفصيل.\n\nفي غضون ذلك، هل تريد معرفة:\n• الأسعار والباقات؟\n• المميزات الأساسية؟\n• طلب عرض توضيحي؟"
    },
    en: {
      greeting: "Hello! I'm Taleik's AI assistant 🤖\n\nI can help you with:\n• Pricing and packages\n• Features and services\n• Platform integration\n• Demo requests\n\nHow can I assist you today?",
      pricing: "💰 Taleik package starts from $59 monthly and includes:\n\n✅ Instant replies within 15 seconds\n✅ Integration with 5+ platforms\n✅ Automatic lead qualification\n✅ Real-time detailed reports\n✅ 24/7 technical support\n\nThis saves you 80% of customer service employee costs! 📈\n\nWould you like a free trial or have other questions?",
      features: "🚀 Taleik's amazing features:\n\n⚡ Instant response within 15 seconds\n🎯 Filter serious customers from browsers\n📋 Organized tickets for your team\n🔗 Seamless integration with all platforms\n📊 Accurate analytics and statistics\n🌐 Arabic language support\n⏰ 24/7 operation without breaks\n\nWhich feature interests you most? Or would you like to see a demo?",
      integration: "🔗 Taleik integrates with all your platforms:\n\n📱 WhatsApp and WhatsApp Business\n📸 Instagram and Direct Messages\n✈️ Telegram\n🌐 Your website\n🛒 Salla store\n🛍️ Shopify\n📘 Facebook Messenger\n\nIntegration takes less than 5 minutes and requires no technical expertise!\n\nWhich platform are you currently using and would like to connect first?",
      support: "🎧 Taleik's technical support team:\n\n✅ Multilingual specialists\n✅ Available 24/7 year-round\n✅ Quick response within minutes\n✅ Remote problem solving\n\n📞 Contact methods:\n• Email: support@taleik.ai\n• Live chat on website\n\nDo you need specific technical assistance?",
      demo: "🎯 Free Taleik trial:\n\n1️⃣ Choose your business type\n2️⃣ Enter your details\n3️⃣ Get trial link instantly\n\n📧 We'll send you:\n• Dashboard access link\n• User guide\n• Free training session\n\nAll within 5 minutes! Would you like to start now?",
      businessTypes: {
        "المطاعم": "🍽️ Taleik is perfect for restaurants:\n\n• Answer menu and price inquiries\n• Book tables automatically\n• Receive delivery orders\n• Set available times\n\nIncreases orders by 40% and saves staff time!",
        "العقارات": "🏠 Taleik helps real estate offices:\n\n• Collect interested customer information\n• Determine budget and specifications\n• Schedule viewing appointments\n• Send suitable offers\n\nTriples qualified customers!",
        "الصيدليات": "💊 Taleik for pharmacies:\n\n• Answer medication inquiries\n• Check product availability\n• Reserve medicines for pickup\n• Medication reminders\n\nImproves customer service and significantly increases sales!"
      },
      contact: "📞 Want to speak with our sales team?\n\nYou can:\n• Fill the waiting list form above\n• Email: sales@taleik.ai\n• Live chat on website\n\nOr leave your details here and I'll pass them to the team directly! 📝",
      default: "🤔 I understand your inquiry, but to get an accurate and detailed answer about this topic, I'll forward your question to our experts.\n\n👥 Our sales team will contact you within one hour to discuss your needs in detail.\n\nMeanwhile, would you like to know about:\n• Pricing and packages?\n• Basic features?\n• Request a demo?"
    }
  };

  const getResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase().trim();
    const responses = predefinedResponses[language];

    // Enhanced keyword matching with more Arabic variations
    if (message.includes("سعر") || message.includes("تكلفة") || message.includes("باقة") || 
        message.includes("price") || message.includes("cost") || message.includes("package") ||
        message.includes("كم") || message.includes("فلوس") || message.includes("money")) {
      return responses.pricing;
    }
    
    if (message.includes("مميزات") || message.includes("خصائص") || message.includes("ميزة") ||
        message.includes("features") || message.includes("capabilities") || message.includes("benefits") ||
        message.includes("فوائد") || message.includes("يقدر") || message.includes("يساعد")) {
      return responses.features;
    }
    
    if (message.includes("ربط") || message.includes("تكامل") || message.includes("ربط") ||
        message.includes("integration") || message.includes("connect") || message.includes("link") ||
        message.includes("واتساب") || message.includes("انستغرام") || message.includes("telegram") ||
        message.includes("whatsapp") || message.includes("instagram") || message.includes("موقع")) {
      return responses.integration;
    }
    
    if (message.includes("دعم") || message.includes("مساعدة") || message.includes("مشكلة") ||
        message.includes("support") || message.includes("help") || message.includes("issue") ||
        message.includes("خطأ") || message.includes("error") || message.includes("contact")) {
      return responses.support;
    }
    
    if (message.includes("تجربة") || message.includes("ديمو") || message.includes("تجريب") ||
        message.includes("demo") || message.includes("trial") || message.includes("test") ||
        message.includes("جرب") || message.includes("اختبار")) {
      return responses.demo;
    }

    // Business type specific responses
    const businessKeywords = {
      "مطعم": "المطاعم",
      "restaurant": "المطاعم", 
      "food": "المطاعم",
      "عقار": "العقارات",
      "real estate": "العقارات",
      "property": "العقارات",
      "صيدلية": "الصيدليات",
      "pharmacy": "الصيدليات",
      "medicine": "الصيدليات"
    };

    for (const [keyword, businessType] of Object.entries(businessKeywords)) {
      if (message.includes(keyword)) {
        return responses.businessTypes?.[businessType] || responses.default;
      }
    }

    // Greeting responses
    if (message.includes("مرحبا") || message.includes("أهلا") || message.includes("السلام") ||
        message.includes("hello") || message.includes("hi") || message.includes("hey") ||
        message.includes("صباح") || message.includes("مساء")) {
      return responses.greeting;
    }

    // Contact/sales related
    if (message.includes("تواصل") || message.includes("مبيعات") || message.includes("بيانات") ||
        message.includes("contact") || message.includes("sales") || message.includes("call")) {
      return responses.contact;
    }

    return responses.default;
  };

  const sendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      sender: "user",
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);

    // Simulate AI thinking time with realistic delay
    const responseDelay = Math.random() * 1000 + 500; // 0.5-1.5 seconds
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: getResponse(userMessage.text),
        sender: "bot",
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, responseDelay);
  };

  const initializeChat = () => {
    if (messages.length === 0) {
      const welcomeMessage: Message = {
        id: "welcome",
        text: predefinedResponses[language].greeting,
        sender: "bot",
        timestamp: new Date()
      };
      setMessages([welcomeMessage]);
    }
  };

  const openChat = () => {
    setIsOpen(true);
    initializeChat();
  };

  return (
    <>
      {/* Floating Chat Button */}
      <motion.div
        className="fixed bottom-6 left-6 z-50"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 2 }}
      >
        <motion.button
          onClick={openChat}
          className="w-16 h-16 bg-primary rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-shadow"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
        >
          <MessageCircle size={24} />
        </motion.button>
      </motion.div>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="fixed bottom-24 left-6 z-50 w-96 max-w-[calc(100vw-3rem)]"
          >
            <Card className="shadow-2xl">
              <div className="bg-primary text-white p-4 rounded-t-lg flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center ml-2">
                    <Bot size={16} />
                  </div>
                  <div>
                    <h3 className="font-semibold">{t('chatDemo.title', 'Taleik AI Assistant')}</h3>
                    <p className="text-xs text-white/80">{t('chatDemo.online', 'Online Now')}</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsOpen(false)}
                  className="text-white hover:bg-white/20 p-1"
                >
                  <X size={16} />
                </Button>
              </div>

              <CardContent className="p-0">
                <div className="h-80 overflow-y-auto p-4 space-y-4">
                  {messages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div className={`flex items-start max-w-[80%] ${message.sender === "user" ? "flex-row-reverse" : ""}`}>
                        <Avatar className="w-6 h-6 mx-2">
                          <AvatarFallback className={`text-xs ${message.sender === "user" ? "bg-primary text-white" : "bg-gray-200"}`}>
                            {message.sender === "user" ? <User size={12} /> : <Bot size={12} />}
                          </AvatarFallback>
                        </Avatar>
                        <div
                          className={`rounded-lg p-3 text-sm ${
                            message.sender === "user"
                              ? "bg-primary text-white"
                              : "bg-gray-100 text-gray-800"
                          }`}
                        >
                          {message.text}
                        </div>
                      </div>
                    </motion.div>
                  ))}

                  {isTyping && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex justify-start"
                    >
                      <div className="flex items-start">
                        <Avatar className="w-6 h-6 mx-2">
                          <AvatarFallback className="bg-gray-200 text-xs">
                            <Bot size={12} />
                          </AvatarFallback>
                        </Avatar>
                        <div className="bg-gray-100 rounded-lg p-3">
                          <div className="flex space-x-1">
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                <div className="p-4 border-t">
                  {/* Quick Action Buttons */}
                  {messages.length <= 1 && (
                    <div className="grid grid-cols-2 gap-2 mb-3">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const userMessage: Message = {
                            id: Date.now().toString(),
                            text: "كم سعر الباقة؟",
                            sender: "user",
                            timestamp: new Date()
                          };
                          setMessages(prev => [...prev, userMessage]);
                          setIsTyping(true);
                          setTimeout(() => {
                            const botResponse: Message = {
                              id: (Date.now() + 1).toString(),
                              text: getResponse("كم سعر الباقة؟"),
                              sender: "bot",
                              timestamp: new Date()
                            };
                            setMessages(prev => [...prev, botResponse]);
                            setIsTyping(false);
                          }, 800);
                        }}
                        className="text-xs p-2 h-auto"
                      >
                        💰 الأسعار
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const userMessage: Message = {
                            id: Date.now().toString(),
                            text: "ما هي المميزات؟",
                            sender: "user",
                            timestamp: new Date()
                          };
                          setMessages(prev => [...prev, userMessage]);
                          setIsTyping(true);
                          setTimeout(() => {
                            const botResponse: Message = {
                              id: (Date.now() + 1).toString(),
                              text: getResponse("ما هي المميزات؟"),
                              sender: "bot",
                              timestamp: new Date()
                            };
                            setMessages(prev => [...prev, botResponse]);
                            setIsTyping(false);
                          }, 900);
                        }}
                        className="text-xs p-2 h-auto"
                      >
                        🚀 المميزات
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const userMessage: Message = {
                            id: Date.now().toString(),
                            text: "أريد تجربة مجانية",
                            sender: "user",
                            timestamp: new Date()
                          };
                          setMessages(prev => [...prev, userMessage]);
                          setIsTyping(true);
                          setTimeout(() => {
                            const botResponse: Message = {
                              id: (Date.now() + 1).toString(),
                              text: getResponse("أريد تجربة مجانية"),
                              sender: "bot",
                              timestamp: new Date()
                            };
                            setMessages(prev => [...prev, botResponse]);
                            setIsTyping(false);
                          }, 700);
                        }}
                        className="text-xs p-2 h-auto"
                      >
                        🎯 تجربة مجانية
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const userMessage: Message = {
                            id: Date.now().toString(),
                            text: "كيف يتكامل مع واتساب؟",
                            sender: "user",
                            timestamp: new Date()
                          };
                          setMessages(prev => [...prev, userMessage]);
                          setIsTyping(true);
                          setTimeout(() => {
                            const botResponse: Message = {
                              id: (Date.now() + 1).toString(),
                              text: getResponse("كيف يتكامل مع واتساب؟"),
                              sender: "bot",
                              timestamp: new Date()
                            };
                            setMessages(prev => [...prev, botResponse]);
                            setIsTyping(false);
                          }, 1000);
                        }}
                        className="text-xs p-2 h-auto"
                      >
                        🔗 التكامل
                      </Button>
                    </div>
                  )}
                  
                  <div className="space-y-3">
                    <div className="text-center">
                      <Button 
                        onClick={() => {
                          // We need to add this functionality
                          window.dispatchEvent(new CustomEvent('openWaitingList'));
                        }}
                        className="w-full bg-teal-600 hover:bg-teal-700 text-white"
                      >
                        Join Waitlist
                      </Button>
                    </div>
                    
                    <div className="flex space-x-2">
                      <Input
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        onKeyPress={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()}
                        placeholder={t('chatDemo.placeholder', 'اكتب رسالتك هنا...')}
                        className="flex-1"
                        disabled={isTyping}
                      />
                      <Button 
                        onClick={sendMessage} 
                        size="sm" 
                        className="px-3"
                        disabled={isTyping || !inputValue.trim()}
                      >
                        <Send size={16} />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}