import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/hooks/use-language";
import { Globe } from "lucide-react";

export default function LanguageToggle() {
  const { language, setLanguage } = useLanguage();

  const toggleLanguage = () => {
    setLanguage(language === "ar" ? "en" : "ar");
  };

  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <Button
        variant="outline"
        size="sm"
        onClick={toggleLanguage}
        className="flex items-center space-x-2 space-x-reverse border-primary/20 hover:bg-primary/10"
      >
        <Globe size={16} />
        <span className="font-medium">
          {language === "ar" ? "English" : "العربية"}
        </span>
      </Button>
    </motion.div>
  );
}