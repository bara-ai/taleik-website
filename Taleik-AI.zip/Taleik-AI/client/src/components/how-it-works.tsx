import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import ScrollReveal from "./scroll-reveal";

export default function HowItWorks() {
  const steps = [
    {
      number: 1,
      title: "سجّل حسابك",
      description: "ادفع 229 ر.س واستلم رابط لوحة التحكم فوراً",
      detail: "عملية سريعة وآمنة، تستغرق أقل من دقيقتين",
      color: "bg-primary"
    },
    {
      number: 2,
      title: "اربط واتساب وأضف الأسئلة الشائعة",
      description: "إعداد بسيط في 10 دقائق بدون تعقيدات تقنية",
      detail: "واجهة سهلة باللغة العربية مع دليل مفصّل",
      color: "bg-secondary"
    },
    {
      number: 3,
      title: "فعّل البوت",
      description: "يبدأ الرد والتصفية وإنشاء التذاكر تلقائياً",
      detail: "نتائج فورية ملحوظة من اليوم الأول",
      color: "bg-green-600"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              كيف يعمل (3 خطوات بسيطة)
            </h2>
            <p className="text-xl text-gray-600">
              من التسجيل إلى البدء في استقبال العملاء الجدد في نفس اليوم
            </p>
          </div>
        </ScrollReveal>
        
        <div className="grid md:grid-cols-3 gap-8 relative">
          {steps.map((step, index) => (
            <ScrollReveal key={index} delay={index * 0.2}>
              <motion.div
                whileHover={{ y: -8 }}
                transition={{ duration: 0.3 }}
                className="text-center"
              >
                <motion.div 
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  transition={{ delay: index * 0.2 + 0.3, type: "spring", stiffness: 200 }}
                  className={`w-20 h-20 ${step.color} rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-6 shadow-lg`}
                >
                  {step.number}
                </motion.div>
                <h3 className="text-xl font-bold mb-4">{step.title}</h3>
                <p className="text-gray-600 mb-4">{step.description}</p>
                <p className="text-sm text-gray-500">{step.detail}</p>
              </motion.div>
            </ScrollReveal>
          ))}
          
          {/* Connecting lines for desktop */}
          <div className="hidden md:block absolute top-10 left-1/4 right-1/4 h-0.5 bg-gradient-to-r from-primary to-secondary"></div>
          <div className="hidden md:block absolute top-10 right-1/4 left-1/4 h-0.5 bg-gradient-to-r from-secondary to-green-600"></div>
        </div>
        
        <ScrollReveal delay={0.6}>
          <div className="text-center mt-16">
            <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 max-w-2xl mx-auto">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">النتيجة:</h3>
                <h4 className="text-xl font-semibold text-primary mb-4">جاهز للعمل في نفس اليوم</h4>
                <p className="text-lg text-gray-600">
                  لا تحتاج مطوّر ولا سيرفر ولا خبرة تقنية
                  <br />
                  فقط 10 دقائق إعداد وتبدأ النتائج فوراً
                </p>
              </CardContent>
            </Card>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
