import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Zap, Filter, Ticket, Link, BarChart, Clock } from "lucide-react";
import ScrollReveal from "./scroll-reveal";

export default function FeaturesSection() {
  const features = [
    {
      icon: Zap,
      title: "رد آلي فوري",
      subtitle: "< 15 ثانية",
      description: "عملاؤك يشعرون بالاهتمام فوراً، مما يزيد معدلات الإغلاق بشكل كبير",
      stat: "95%",
      statLabel: "تحسن في الاستجابة",
      gradient: "from-primary/5 to-secondary/5",
      iconBg: "bg-primary"
    },
    {
      icon: Filter,
      title: "فرز العميل المهتم",
      subtitle: "ذكاء اصطناعي متقدم",
      description: "لا تضيع وقتك مع استفسارات عابرة، تركيز كامل على المشتري الحقيقي",
      stat: "78%",
      statLabel: "تحسن في جودة العملاء",
      gradient: "from-secondary/5 to-primary/5",
      iconBg: "bg-secondary"
    },
    {
      icon: Ticket,
      title: "تذكرة جاهزة للفريق",
      subtitle: "معلومات كاملة",
      description: "فريقك البشري يستلم كل التفاصيل ويبدأ العمل مباشرة بكفاءة عالية",
      stat: "85%",
      statLabel: "توفير في الوقت",
      gradient: "from-green-50 to-emerald-50",
      iconBg: "bg-green-600"
    },
    {
      icon: Link,
      title: "تكامل سلس",
      subtitle: "جميع المنصات",
      description: "يربط واتساب، انستجرام، موقعك... في لوحة تحكم عربية واحدة",
      stat: "99%",
      statLabel: "نجاح التكامل",
      gradient: "from-blue-50 to-indigo-50",
      iconBg: "bg-blue-600"
    },
    {
      icon: BarChart,
      title: "تحليلات لحظية",
      subtitle: "قرارات ذكية",
      description: "أرقام واضحة ومؤشرات دقيقة لاتخاذ قرارات أسرع وتحسين مستمر",
      stat: "200%",
      statLabel: "تحسن في اتخاذ القرارات",
      gradient: "from-purple-50 to-pink-50",
      iconBg: "bg-purple-600"
    },
    {
      icon: Clock,
      title: "خدمة عملاء 24/7",
      subtitle: "بدون توقف",
      description: "موظف ذكي لا ينام ولا يأخذ إجازات، خدمة متواصلة طوال أيام السنة",
      stat: "24/7",
      statLabel: "متاح دائماً",
      gradient: "from-green-50 to-emerald-50",
      iconBg: "bg-green-600"
    }
  ];

  return (
    <section id="features" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              هنا يأتي دور 'طليق:
            </h2>
            <p className="text-xl text-primary font-semibold">
              موظّفك الذكي 24/7
            </p>
          </div>
        </ScrollReveal>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <ScrollReveal key={index} delay={index * 0.1}>
              <motion.div
                whileHover={{ y: -8 }}
                transition={{ duration: 0.3 }}
              >
                <Card className={`h-full bg-gradient-to-br ${feature.gradient} card-hover`}>
                  <CardContent className="p-8">
                    <div className={`w-16 h-16 ${feature.iconBg} rounded-2xl flex items-center justify-center mb-6`}>
                      <feature.icon className="text-white" size={32} />
                    </div>
                    <h3 className="text-2xl font-bold mb-3">{feature.title}</h3>
                    <div className={`text-lg font-semibold mb-2 ${feature.iconBg.replace('bg-', 'text-')}`}>
                      {feature.subtitle}
                    </div>
                    <p className="text-gray-600 mb-4">{feature.description}</p>
                    <Badge className={`${feature.iconBg} text-white border-none`}>
                      <span className="font-bold">{feature.stat}</span> {feature.statLabel}
                    </Badge>
                  </CardContent>
                </Card>
              </motion.div>
            </ScrollReveal>
          ))}
        </div>
        
        <ScrollReveal delay={0.6}>
          <div className="text-center mt-16">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              تحسن في خدمة العملاء بنسبة 60-80% وزيادة المبيعات 15% خلال أول 30 يوم
            </h3>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
