import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface ABTest {
  id: string;
  name: string;
  variants: {
    control: any;
    variant: any;
  };
  activeVariant: "control" | "variant";
}

interface ABTestContextType {
  getVariant: (testId: string) => "control" | "variant";
  trackConversion: (testId: string, event: string) => void;
  tests: Record<string, ABTest>;
}

const ABTestContext = createContext<ABTestContextType | undefined>(undefined);

// A/B Test configurations
const abTests = {
  heroHeadline: {
    id: "heroHeadline",
    name: "Hero Headline Test",
    variants: {
      control: {
        title: "موظّف ذكاء اصطناعي يرد على عملاءك في 15 ثانية",
        subtitle: "بتكلفة أقل من فنجان قهوة!"
      },
      variant: {
        title: "احصل على ردود فورية لعملائك خلال 15 ثانية فقط",
        subtitle: "وفّر 80% من تكلفة موظف خدمة العملاء"
      }
    },
    activeVariant: "control" as "control" | "variant"
  },
  pricingCard: {
    id: "pricingCard",
    name: "Pricing Card Color Test",
    variants: {
      control: {
        buttonColor: "bg-primary",
        buttonText: "جرّبه الآن بـ 229 ر.س",
        urgency: false
      },
      variant: {
        buttonColor: "bg-red-600",
        buttonText: "احجز الآن - عرض محدود!",
        urgency: true
      }
    },
    activeVariant: "control" as "control" | "variant"
  },
  featureLayout: {
    id: "featureLayout",
    name: "Feature Section Layout Test",
    variants: {
      control: {
        layout: "grid",
        columns: "lg:grid-cols-3"
      },
      variant: {
        layout: "carousel",
        columns: "lg:grid-cols-2"
      }
    },
    activeVariant: "control" as "control" | "variant"
  }
};

export function ABTestProvider({ children }: { children: ReactNode }) {
  const [tests, setTests] = useState<Record<string, ABTest>>(abTests);
  const [userAssignments, setUserAssignments] = useState<Record<string, "control" | "variant">>({});

  useEffect(() => {
    // Load user assignments from localStorage or generate new ones
    const savedAssignments = localStorage.getItem("abTestAssignments");
    if (savedAssignments) {
      setUserAssignments(JSON.parse(savedAssignments));
    } else {
      // Assign user to variants (50/50 split)
      const newAssignments: Record<string, "control" | "variant"> = {};
      Object.keys(abTests).forEach(testId => {
        newAssignments[testId] = Math.random() < 0.5 ? "control" : "variant";
      });
      setUserAssignments(newAssignments);
      localStorage.setItem("abTestAssignments", JSON.stringify(newAssignments));
    }
  }, []);

  const getVariant = (testId: string): "control" | "variant" => {
    return userAssignments[testId] || "control";
  };

  const trackConversion = (testId: string, event: string) => {
    // In a real application, this would send data to analytics
    const variant = getVariant(testId);
    console.log(`A/B Test Conversion: ${testId} - ${variant} - ${event}`);
    
    // Store conversion data
    const conversions = JSON.parse(localStorage.getItem("abTestConversions") || "[]");
    conversions.push({
      testId,
      variant,
      event,
      timestamp: new Date().toISOString()
    });
    localStorage.setItem("abTestConversions", JSON.stringify(conversions));
  };

  return (
    <ABTestContext.Provider value={{ getVariant, trackConversion, tests }}>
      {children}
    </ABTestContext.Provider>
  );
}

export function useABTest() {
  const context = useContext(ABTestContext);
  if (context === undefined) {
    throw new Error("useABTest must be used within an ABTestProvider");
  }
  return context;
}