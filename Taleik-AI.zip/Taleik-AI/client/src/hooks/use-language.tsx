import { createContext, useContext, useState, ReactNode } from "react";

type Language = "ar" | "en";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string, fallback?: string) => string;
}

const translations = {
  ar: {
    // Navigation
    'nav.features': 'المميزات',
    'nav.pricing': 'الأسعار',
    'nav.testimonials': 'آراء العملاء',
    'nav.contact': 'تواصل معنا',
    'nav.tryNow': 'جرب الآن',
    
    // Hero section
    'hero.title': 'موظّف ذكاء اصطناعي يرد',
    'hero.title2': 'على عملاءك في 15 ثانية',
    'hero.subtitle': 'بتكلفة أقل من فنجان قهوة!',
    'hero.description': 'وفّر 60-80% من وقت وجهد خدمة العملاء مع باقة المشاريع الصغيرة من Taleik',
    'hero.price': '229 ر.س',
    'hero.priceOld': '799 ر.س',
    'hero.discount': 'خصم 71%',
    'hero.seatsLeft': 'متبقي 37 مقعد فقط من أصل 50 مقعد',
    'hero.cta': 'جرّبه الآن بـ 229 ر.س',
    'hero.noFees': 'لا توجد رسوم تفعيل • إلغاء في أي وقت',
    'hero.trusted': 'موثوق به لدى أكثر من 200 مشروع سعودي',
    
    // Chat Demo
    'chatDemo.title': 'مساعد Taleik الذكي',
    'chatDemo.online': 'متاح الآن',
    'chatDemo.placeholder': 'اكتب رسالتك هنا...',
    
    // Problem section
    'problem.title': 'رسائل العملاء تتكدّس؟',
    'problem.subtitle': 'كل دقيقة تأخير = عميل ضائع',
    
    // Features section
    'features.title': 'هنا يأتي دور Taleik:',
    'features.subtitle': 'موظّفك الذكي 24/7',
    
    // Business selector
    'business.title': 'جرّب Taleik الآن',
    'business.subtitle': 'تحدث مع الذكاء الاصطناعي مباشرة',
    'business.description': 'هذا هو Taleik الحقيقي! اختر نوع عملك وتحدث معه واكتشف كيف سيساعد عملاءك ويزيد مبيعاتك',
    'business.selectType': 'اختر نوع عملك لترى كيف يساعدك Taleik',
    'business.clickInfo': 'انقر على أي نوع عمل لترى الفوائد المحددة',
    
    // Integration section
    'integration.title': 'يتكامل مع جميع منصاتك',
    'integration.subtitle': 'بضغطة زر واحدة',
    'integration.description': 'سواء كنت صاحب عمل تقليدي أو متجر إلكتروني، نحن نخدم الجميع',
    
    // Pricing section
    'pricing.title': 'كل ما تحتاجه في باقة واحدة…',
    'pricing.subtitle': 'بسعر يسهل اتخاذ القرار',
    
    // How it works
    'howItWorks.title': 'كيف يعمل (3 خطوات بسيطة)',
    'howItWorks.subtitle': 'من التسجيل إلى البدء في استقبال العملاء الجدد في نفس اليوم',
    
    // Testimonials
    'testimonials.title': 'شهادات العملاء',
    'testimonials.subtitle': 'ماذا يقول عملاؤنا عن تجربتهم',
    
    // FAQ
    'faq.title': 'الأسئلة الشائعة',
    'faq.subtitle': 'كل ما تريد معرفته عن Taleik وباقة المشاريع الصغيرة',
    
    // Final CTA
    'finalCta.title': 'حول رسائلك المزعجة إلى فرص بيع',
    'finalCta.subtitle': 'في دقائق معدودة',
    'finalCta.lastChance': 'آخر فرصة',
    'finalCta.cta': 'احجز مقعدك الآن بـ 229 ر.س',
    
    // Footer
    'footer.description': 'موظّف ذكاء اصطناعي يرد على عملاءك في 15 ثانية',
    'footer.services': 'الخدمات',
    'footer.company': 'الشركة',
    'footer.support': 'الدعم',
    'footer.rights': 'جميع الحقوق محفوظة'
  },
  en: {
    // Navigation
    'nav.features': 'Features',
    'nav.pricing': 'Pricing',
    'nav.testimonials': 'Testimonials',
    'nav.contact': 'Contact',
    'nav.tryNow': 'Try Now',
    
    // Hero section
    'hero.title': 'AI Employee that responds',
    'hero.title2': 'to your customers in 15 seconds',
    'hero.subtitle': 'For less than the cost of a cup of coffee!',
    'hero.description': 'Save 60-80% of customer service time and effort with Taleik\'s small business package',
    'hero.price': '229 SAR',
    'hero.priceOld': '799 SAR',
    'hero.discount': '71% OFF',
    'hero.seatsLeft': 'Only 37 seats left out of 50',
    'hero.cta': 'Try Now for 229 SAR',
    'hero.noFees': 'No activation fees • Cancel anytime',
    'hero.trusted': 'Trusted by over 200 Saudi projects',
    
    // Chat Demo
    'chatDemo.title': 'Taleik AI Assistant',
    'chatDemo.online': 'Online Now',
    'chatDemo.placeholder': 'Type your message here...',
    
    // Problem section
    'problem.title': 'Customer messages piling up?',
    'problem.subtitle': 'Every minute of delay = lost customer',
    
    // Features section
    'features.title': 'Here comes Taleik:',
    'features.subtitle': 'Your smart employee 24/7',
    
    // Business selector
    'business.title': 'Try Taleik Now',
    'business.subtitle': 'Chat directly with AI',
    'business.description': 'This is the real Taleik! Choose your business type and chat with it to discover how it will help your customers and increase your sales',
    'business.selectType': 'Choose your business type to see how Taleik helps you',
    'business.clickInfo': 'Click on any business type to see specific benefits',
    
    // Integration section
    'integration.title': 'Integrates with all your platforms',
    'integration.subtitle': 'With one click',
    'integration.description': 'Whether you\'re a traditional business owner or an e-commerce store, we serve everyone',
    
    // Pricing section
    'pricing.title': 'Everything you need in one package…',
    'pricing.subtitle': 'At a price that makes decisions easy',
    
    // How it works
    'howItWorks.title': 'How it works (3 simple steps)',
    'howItWorks.subtitle': 'From registration to start receiving new customers on the same day',
    
    // Testimonials
    'testimonials.title': 'Customer Testimonials',
    'testimonials.subtitle': 'What our customers say about their experience',
    
    // FAQ
    'faq.title': 'Frequently Asked Questions',
    'faq.subtitle': 'Everything you want to know about Taleik and the small business package',
    
    // Final CTA
    'finalCta.title': 'Turn your annoying messages into sales opportunities',
    'finalCta.subtitle': 'In minutes',
    'finalCta.lastChance': 'Last chance',
    'finalCta.cta': 'Reserve your seat now for 229 SAR',
    
    // Footer
    'footer.description': 'AI employee that responds to your customers in 15 seconds',
    'footer.services': 'Services',
    'footer.company': 'Company',
    'footer.support': 'Support',
    'footer.rights': 'All rights reserved'
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("ar");

  const t = (key: string, fallback?: string): string => {
    const translation = translations[language][key as keyof typeof translations[typeof language]];
    return translation || fallback || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}