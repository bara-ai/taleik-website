import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { LanguageProvider } from "@/hooks/use-language";
import { ABTestProvider } from "@/hooks/use-ab-test";
import Home from "@/pages/home";
import NotFound from "@/pages/not-found";
import WaitingListModal from "@/components/waiting-list-modal";
import { useState, useEffect } from "react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [showWaitingList, setShowWaitingList] = useState(false);

  useEffect(() => {
    const handleOpenWaitingListFromChat = () => {
      setShowWaitingList(true);
    };

    const handleOpenWaitingListFromCTA = () => {
      setShowWaitingList(true);
    };

    window.addEventListener('openWaitingListFromChat', handleOpenWaitingListFromChat);
    window.addEventListener('openWaitingListFromCTA', handleOpenWaitingListFromCTA);

    return () => {
      window.removeEventListener('openWaitingListFromChat', handleOpenWaitingListFromChat);
      window.removeEventListener('openWaitingListFromCTA', handleOpenWaitingListFromCTA);
    };
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <ABTestProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
            <WaitingListModal 
              isOpen={showWaitingList} 
              onClose={() => setShowWaitingList(false)} 
            />
          </TooltipProvider>
        </ABTestProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;