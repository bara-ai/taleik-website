import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import ProblemSection from "@/components/problem-section";
import FeaturesSection from "@/components/features-section";
import BusinessSelector from "@/components/business-selector";
import IntegrationSection from "@/components/integration-section";
import PricingSection from "@/components/pricing-section";
import HowItWorks from "@/components/how-it-works";
import Testimonials from "@/components/testimonials";
import FAQSection from "@/components/faq-section";
import FinalCTA from "@/components/final-cta";
import Footer from "@/components/footer";
import ChatDemo from "@/components/chat-demo";
import { useLanguage } from "@/hooks/use-language";
import { useEffect } from "react";

export default function Home() {
  const { language } = useLanguage();

  useEffect(() => {
    // Update document direction based on language
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = language;
  }, [language]);

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <HeroSection />
      <ProblemSection />
      <FeaturesSection />
      <BusinessSelector />
      <IntegrationSection />
      <PricingSection />
      <HowItWorks />
      <Testimonials />
      <FAQSection />
      <FinalCTA />
      <Footer />
      <ChatDemo />
    </div>
  );
}
