import { z } from "zod";
import { createInsertSchema } from "drizzle-zod";

// Waiting List Form Schema
export const waitingListSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  businessEmail: z.string().email("Valid email is required"),
  phone: z.string().min(1, "Phone number is required"),
  jobTitle: z.string().min(1, "Job title is required"),
  additionalComments: z.string().optional(),
});

export type WaitingListFormData = z.infer<typeof waitingListSchema>;