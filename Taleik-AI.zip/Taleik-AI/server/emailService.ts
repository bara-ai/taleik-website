import { MailService } from "@sendgrid/mail";
import type { WaitingListFormData } from "@shared/schema";

if (!process.env.SENDGRID_API_KEY) {
  throw new Error("SENDGRID_API_KEY environment variable must be set");
}

const mailService = new MailService();
mailService.setApiKey(process.env.SENDGRID_API_KEY);

export async function sendWaitingListEmail(
  formData: WaitingListFormData,
): Promise<boolean> {
  try {
    // Check if SendGrid API key is available
    if (!process.env.SENDGRID_API_KEY) {
      console.error("SENDGRID_API_KEY environment variable is not set");
      return false;
    }

    const emailContent = `
New Waiting List Submission for Taleik AI

First Name: ${formData.firstName}
Last Name: ${formData.lastName}
Business Email: ${formData.businessEmail}
Phone: ${formData.phone}
Job Title: ${formData.jobTitle}
Additional Comments: ${formData.additionalComments || "None"}

Submitted at: ${new Date().toISOString()}
    `;

    const emailData = {
      to: "baraa@taleik.ai",
      from: "baraaabuqare6@gmail.com", // This should be verified with SendGrid
      subject: "New Waiting List Submission - Taleik AI",
      text: emailContent,
      html: emailContent.replace(/\n/g, "<br>"),
    };

    console.log(
      "Attempting to send email with data:",
      JSON.stringify(emailData, null, 2),
    );

    const result = await mailService.send(emailData);
    console.log("Email sent successfully:", result);

    return true;
  } catch (error: any) {
    console.error("SendGrid email error:", error);
    if (error.response) {
      console.error("Response body:", error.response.body);
      console.error("Response status:", error.response.status);
    }
    return false;
  }
}
