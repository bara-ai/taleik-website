import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { waitingListSchema } from "@shared/schema";
import { sendWaitingListEmail } from "./emailService";

// Contact form schema
const contactFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  phone: z.string().optional(),
  businessType: z.string().optional(),
  message: z.string().min(10, "Message must be at least 10 characters")
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission endpoint
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = contactFormSchema.parse(req.body);
      
      // In a real application, you would:
      // 1. Save to database
      // 2. Send email notification
      // 3. Integration with CRM
      
      console.log("Contact form submission:", validatedData);
      
      res.json({ 
        success: true, 
        message: "شكراً لتواصلك معنا. سنعاود الاتصال بك قريباً!" 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          success: false, 
          message: "بيانات غير صحيحة", 
          errors: error.errors 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: "حدث خطأ في الخادم" 
        });
      }
    }
  });

  // Demo request endpoint
  app.post("/api/demo", async (req, res) => {
    try {
      const demoSchema = z.object({
        email: z.string().email(),
        businessType: z.string(),
        company: z.string().optional()
      });
      
      const validatedData = demoSchema.parse(req.body);
      
      // Store demo request
      console.log("Demo request:", validatedData);
      
      res.json({ 
        success: true, 
        message: "تم تسجيل طلب التجربة بنجاح!" 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          success: false, 
          message: "بيانات غير صحيحة" 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: "حدث خطأ في الخادم" 
        });
      }
    }
  });

  // Newsletter subscription
  app.post("/api/newsletter", async (req, res) => {
    try {
      const newsletterSchema = z.object({
        email: z.string().email()
      });
      
      const validatedData = newsletterSchema.parse(req.body);
      
      console.log("Newsletter subscription:", validatedData);
      
      res.json({ 
        success: true, 
        message: "تم الاشتراك في النشرة الإخبارية بنجاح!" 
      });
    } catch (error) {
      res.status(400).json({ 
        success: false, 
        message: "بريد إلكتروني غير صحيح" 
      });
    }
  });

  // Waiting list submission endpoint
  app.post("/api/waiting-list", async (req, res) => {
    try {
      const validatedData = waitingListSchema.parse(req.body);
      
      // Send email notification
      const emailSent = await sendWaitingListEmail(validatedData);
      
      if (!emailSent) {
        console.error("Failed to send waiting list email");
        // Still return success to user, but log the error
      }
      
      console.log("Waiting list submission:", validatedData);
      
      res.json({ 
        success: true, 
        message: "لقد قمت بتسجيل عملك بنجاح، سيتم التواصل معك قريبا" 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          success: false, 
          message: "بيانات غير صحيحة", 
          errors: error.errors 
        });
      } else {
        console.error("Waiting list submission error:", error);
        res.status(500).json({ 
          success: false, 
          message: "حدث خطأ في الخادم" 
        });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
